# Tableau Build

Calculated fields: Claim Cost = SUM([Paid Amount])+SUM([Reserve Amount]); Loss Ratio = SUM([Paid Amount])/SUM([Premium]); Claim Frequency = COUNTD([Claim ID])/COUNTD([Policy ID]); Fraud Flag Rate = AVG(IIF([Fraud Indicator]='Y',1,0)); Open Claim = IIF([Claim Status]<>'Closed',1,0).

Build distinct storytelling dashboards: 1) Geographic Risk map/parameter, 2) Claims Trend with highlight actions, 3) Severity box plots and top-decile high-value claims, 4) Operations aging and adjuster workload, 5) Executive Story using story points and annotations.
