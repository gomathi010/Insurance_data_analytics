# Power BI — 5 Page Build

## 1 Executive Claims Overview
KPI cards: Total Claims, Total Claim Cost, Average Severity, Claims Outstanding, Loss Ratio. Monthly claims/cost trend, claims by type, claims by province, paid vs reserve.

## 2 Claims Operations
Processing-time trend, status mix, adjuster workload scatter, settlement aging buckets, bottleneck table. Drill-through to adjuster detail.

## 3 Claims Severity
Severity distribution, claim amount histogram, top high-value claims, severity by type and province.

## 4 Fraud & Risk
Fraud-rate trend, fraud by type, suspicious claims table, amount anomaly scatter, high-risk segment matrix.

## 5 Profitability
Premium vs paid claims, loss ratio by policy type, cost trend, policy profitability matrix.

## Interactivity
Slicers, synchronized filters, drill-through, report-page tooltips, bookmarks, navigation buttons and dynamic titles.
