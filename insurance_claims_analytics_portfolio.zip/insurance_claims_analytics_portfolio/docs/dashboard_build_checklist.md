# Dashboard Build Checklist
- [ ] Load star-schema CSVs into Power BI
- [ ] Create dimension-to-fact relationships
- [ ] Add DAX measures
- [ ] Build five Power BI pages
- [ ] Add slicers, drill-through, tooltips and bookmarks
- [ ] Validate KPIs against SQL
- [ ] Build distinct Tableau dashboards/story
- [ ] Export screenshots for README
- [ ] Add GitHub link to resume/portfolio
