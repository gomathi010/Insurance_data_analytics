# Data Dictionary

| Field | Meaning | Business use |
|---|---|---|
| Claim ID | Unique claim key | Claim tracking |
| Policy ID | Policy key | Exposure |
| Customer ID | Customer key | Segmentation |
| Claim Date | FNOL/report date | Trends |
| Accident Date | Date of loss | Reporting lag |
| Claim Type | Loss category | Mix/severity |
| Policy Type | Product | Profitability |
| Province | Canadian province | Geography |
| Customer Age Group | Age band | Segmentation |
| Vehicle/Property Type | Asset category | Risk |
| Claim Severity | Low/Medium/High/Critical | Severity |
| Claim Status | Workflow state | Operations |
| Claim Amount | Reported loss | Severity |
| Approved Amount | Approved settlement basis | Claims control |
| Paid Amount | Cash paid | Loss ratio |
| Reserve Amount | Remaining reserve | Outstanding exposure |
| Adjuster ID | Assigned adjuster | Workload |
| Adjuster Experience | Years | Productivity |
| Claim Processing Days | Cycle time | SLA |
| Fraud Indicator | Simulated Y/N flag | Risk |
| Settlement Date | Settlement date | Cycle time |
| Customer Tenure | Years insured | Segmentation |
| Premium | Simulated annual premium | Profitability |
