# Interview Preparation

## 10 Technical
1. How did you make the dataset realistic? — Modeled claims as a fact table with customer, policy, adjuster, geography and date dimensions, then added controlled quality issues.
2. How did you remove duplicates? — Used Claim ID as the business key.
3. How did you validate dates? — Accident cannot follow claim date; settlement cannot precede claim date.
4. Why a star schema? — Simple filter paths, reusable dimensions and cleaner BI measures.
5. How did you treat outliers? — Profiled, preserved raw values and capped operational extremes only in the analytical layer.
6. How did you calculate outstanding exposure? — Approved minus paid, floored at zero.
7. Frequency vs severity? — Frequency is occurrence relative to exposure; severity is financial size.
8. What does loss ratio mean? — Paid losses relative to premium under this simplified portfolio definition.
9. How would you productionize? — Database/cloud ingestion, automated quality checks, scheduled refresh and governed semantic model.
10. How did you validate the dashboard? — Reconciled KPIs to SQL and tested filters/relationships.

## 10 Business Analyst
1. Biggest bottleneck? — Combine queue size, aging, processing time and workload.
2. Claims increasing? — Separate frequency from exposure growth and identify product/geographic/event drivers.
3. High loss ratio? — Explain product, trend, drivers and actions.
4. Stakeholders? — Claims, underwriting, finance, actuarial, SIU, product and CX.
5. Prioritization? — Financial impact, customer impact, feasibility and risk.
6. Good insight? — Observation + business impact + action + measurable outcome.
7. Requirements? — KPI definitions, acceptance criteria and test cases.
8. Conflicting definitions? — Govern one metric definition and owner.
9. High-performing adjuster? — Identify repeatable practices and standardize them.
10. Success metrics? — Cycle time, closure, reserve accuracy, customer outcomes and cost.

## 10 Power BI
1. Star schema? — Better filter propagation and simpler DAX.
2. Measure vs column? — Measures respond to filter context; columns are stored row calculations.
3. Loss ratio? — DIVIDE(Paid Claims, Premium).
4. Dynamic title? — Concatenate formatted measures.
5. Drill-through? — Configure target page fields and navigation from summary visuals.
6. Performance? — Reduce columns/cardinality, star schema, efficient DAX.
7. Bookmarks? — Save report states for navigation/view switching.
8. Slicers? — Modify filter context across visuals.
9. DAX validation? — Reconcile with SQL.
10. Security? — Row-level security in the service.

## 10 SQL
1. Monthly claims — GROUP BY month.
2. Top claim types by cost — GROUP BY + ORDER BY/LIMIT.
3. Loss ratio by policy — JOIN fact/dim + aggregate.
4. Slow adjusters — compare AVG processing days to portfolio average.
5. Paid over approved — WHERE PaidAmount > ApprovedAmount.
6. Province frequency — claims / distinct policies.
7. Oldest open claims — WHERE status <> Closed ORDER BY claim date.
8. Province rank — DENSE_RANK window function.
9. Rolling 3 months — window frame over monthly aggregates.
10. Duplicate IDs — GROUP BY ClaimID HAVING COUNT(*)>1.

## 5 Insurance Claims
1. Reserve? — Expected remaining cost of an open claim.
2. Severity? — Financial size of a claim.
3. Frequency? — Claim occurrence relative to exposure.
4. Loss ratio? — Losses relative to premium.
5. Fraud analytics? — Reduces leakage and focuses investigative resources.

## Project story
“I built a 100,000-record synthetic insurance claims environment, introduced realistic data-quality issues, cleaned and validated the data in Python, modeled a star schema, analyzed it in SQL, and designed Power BI/Tableau experiences for executives, operations, severity, fraud and profitability.”
