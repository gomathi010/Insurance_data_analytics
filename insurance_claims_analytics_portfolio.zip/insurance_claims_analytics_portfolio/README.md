# Insurance Claims Analytics & Operations Intelligence Dashboard

A production-style synthetic insurance analytics portfolio for Insurance Data Analyst, Business Analyst, Operations Analyst and Claims Analyst roles.

## Business problem
Leadership needs to understand claim volume, severity, operational bottlenecks, fraud risk and profitability across products and Canadian provinces.

## Stack
Python/Pandas | SQL | Power BI/DAX | Tableau | GitHub

## Analytics lifecycle
Raw data → profiling → cleaning/validation → star schema → SQL → Python EDA → Power BI → Tableau → recommendations.

## Repository
- `data/`: raw, cleaned and star-schema datasets
- `python/`: cleaning/EDA script
- `sql/`: schema and analytical queries
- `powerbi/`: DAX and five-page build specification
- `tableau/`: calculated fields and storytelling specification
- `docs/`: dictionary, insights, interviews and portfolio narrative

## Important
All data is synthetic. KPI definitions are simplified for portfolio demonstration and should not be presented as actual insurer performance.
