import pandas as pd, numpy as np
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
df=pd.read_csv(ROOT/"data/insurance_claims_raw.csv",parse_dates=["Claim Date","Accident Date","Settlement Date"])
print("Raw rows:",len(df),"Unique claims:",df["Claim ID"].nunique())
df=df.drop_duplicates("Claim ID")
for c in ["Claim Type","Policy Type","Province","Customer Age Group","Vehicle/Property Type","Claim Severity","Claim Status","Fraud Indicator","Adjuster ID"]: df[c]=df[c].astype("string").str.strip()
df["Province"]=df["Province"].fillna("Unknown"); df["Claim Type"]=df["Claim Type"].fillna("Unknown"); df["Customer Age Group"]=df["Customer Age Group"].fillna("Unknown"); df["Adjuster ID"]=df["Adjuster ID"].fillna("Unassigned")
df["Premium"]=df["Premium"].fillna(df.groupby("Policy Type")["Premium"].transform("median")); df["Claim Processing Days"]=df["Claim Processing Days"].fillna(df.groupby("Claim Type")["Claim Processing Days"].transform("median"))
df.loc[df["Accident Date"]>df["Claim Date"],"Accident Date"]=df["Claim Date"]; df.loc[df["Settlement Date"]<df["Claim Date"],"Settlement Date"]=pd.NaT
df["Claim Processing Days"]=df["Claim Processing Days"].clip(upper=df["Claim Processing Days"].quantile(.99)); df["Outstanding Amount"]=(df["Approved Amount"]-df["Paid Amount"]).clip(lower=0); df["Loss Ratio"]=df["Paid Amount"]/df["Premium"].replace(0,np.nan)
df.to_csv(ROOT/"data/insurance_claims_clean_from_script.csv",index=False)
