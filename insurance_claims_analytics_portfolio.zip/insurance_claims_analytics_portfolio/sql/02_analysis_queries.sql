-- Monthly trend
SELECT DATE_TRUNC('month',ClaimDate) month, COUNT(*) claims, SUM(PaidAmount+ReserveAmount) cost FROM fact_claims GROUP BY 1 ORDER BY 1;

-- Cost by type
SELECT ClaimType, COUNT(*) claims, SUM(PaidAmount+ReserveAmount) cost, AVG(ClaimAmount) avg_severity FROM fact_claims GROUP BY ClaimType ORDER BY cost DESC;

-- Province frequency
SELECT g.Province, COUNT(*) claims, COUNT(*)::numeric/NULLIF(COUNT(DISTINCT p.PolicyID),0) frequency FROM fact_claims f JOIN dim_geography g USING(GeographyKey) JOIN dim_policy p USING(PolicyKey) GROUP BY g.Province ORDER BY frequency DESC;

-- Adjuster bottlenecks
SELECT a.AdjusterID,a.AdjusterExperience,COUNT(*) claims,AVG(f.ClaimProcessingDays) avg_days FROM fact_claims f JOIN dim_adjuster a USING(AdjusterKey) GROUP BY 1,2 HAVING COUNT(*)>=50 ORDER BY avg_days DESC;

-- Fraud segments
SELECT Province,ClaimType,PolicyType,COUNT(*) claims,AVG(FraudFlag) fraud_rate,AVG(ClaimAmount) avg_amount FROM fact_claims GROUP BY 1,2,3 HAVING COUNT(*)>=100 ORDER BY fraud_rate DESC;

-- Loss ratio by product
SELECT p.PolicyType,SUM(f.PaidAmount) paid,SUM(p.Premium) premium,SUM(f.PaidAmount)/NULLIF(SUM(p.Premium),0) loss_ratio FROM fact_claims f JOIN dim_policy p USING(PolicyKey) GROUP BY 1 ORDER BY loss_ratio DESC;

-- Data quality checks
SELECT SUM(CASE WHEN AccidentDate>ClaimDate THEN 1 ELSE 0 END) invalid_accident_dates,SUM(CASE WHEN SettlementDate<ClaimDate THEN 1 ELSE 0 END) invalid_settlement_dates,SUM(CASE WHEN PaidAmount>ApprovedAmount THEN 1 ELSE 0 END) paid_over_approved FROM fact_claims;
